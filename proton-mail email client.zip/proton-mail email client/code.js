//Dummy text usable through out the code
const dummyTxt = 'Dummy text.....Feel free to change the text. Functional programming is a part of a larger programming paradigm programming. Declarative programming is a style of programming where applications are structured in a way that prioritizes describing what should happen over defining how it should happen.\nClick the send icon at the top left to send your mail';

//All variables declared here are the sidebar components
const swicthThemeOption = document.querySelector('#Theme-switcher');
const dropDownIcon = document.querySelector('#Theme-switcher img:last-of-type');
const themeMenu = document.querySelector('#theme-switcher-menu ');
const sideBar = document.querySelector('#side-bar-menu');
const collapseMenuIcon = document.querySelector('#collapse-menu-desktop');
const menuOptionContent = document.querySelectorAll(' #side-bar-menu b ');
const menuImg = document.querySelectorAll('.menu-option img');
const themeRadioinput = document.querySelectorAll('#theme-switcher-menu label input');


//This controls the opening and closing the themes dropdown menu
let themeMenuOpen = false;
swicthThemeOption.addEventListener('click', () => {
    !themeMenuOpen ?
        (themeMenu.style.height = '205px', dropDownIcon.style.rotate = '180deg', themeMenuOpen = true) :
        (themeMenuOpen = false, dropDownIcon.style.rotate = 'initial', themeMenu.style.height = 0);
});



//This controls the opening and closing of the sidebar menu
let sideBarOpen = true;
collapseMenuIcon.addEventListener('click', function openMenu() {
    if (sideBarOpen) {
        sideBar.setAttribute('style', 'width: 80px');
        collapseMenuIcon.setAttribute('style', 'inset: 30px 0 0 50%;  translate: -50%; rotate: 360deg');
        dropDownIcon.setAttribute('style', 'display: none');
        menuImg.forEach(el => el.setAttribute('style', 'inset: 7px 0 0 -23px;'));
        menuOptionContent.forEach(el => el.style.display = 'none');
        themeRadioinput.forEach(el => el.style.display = 'none');
        sideBarOpen = false;
    } else {
        sideBar.setAttribute('style', 'width: 300px');
        collapseMenuIcon.setAttribute('style', 'inset: 30px 0 0 90%;  translate: -100%; rotate: -180deg');
        dropDownIcon.setAttribute('style', 'display: inline;');
        menuImg.forEach(el => el.setAttribute('style', 'inset: 7px 0 0 -23px;'));
        menuOptionContent.forEach(el => el.style.display = 'inline');
        themeRadioinput.forEach(el => el.style.display = 'inline');
        sideBarOpen = true;
    }
});



//This controls the opening and closing of the users profile dropdown menu
const profileDropdown = document.querySelector('#user-profile-wrapper img:last-child');
const userImage = document.querySelector('#user-profile-image');
const pdContent = document.querySelector('#user-extra-info');
pdIsVisible = false;

profileDropdown.addEventListener('click', e => {
    if (!pdIsVisible) {
        e.target.style.rotate = '180deg';
        pdContent.setAttribute('style', 'height: 350px; padding: 1rem; box-shadow: 0 0 0 2px gray');
        pdIsVisible = true;
    } else {
        e.target.style.rotate = 'initial';
        pdContent.setAttribute('style', 'height: 0; padding: 0; box-shadow: 0');
        pdIsVisible = false;
    }
})

userImage.addEventListener('click', e => {
    if (!pdIsVisible) {
        pdContent.setAttribute('style', 'height: 350px; padding: 1rem; box-shadow: 0 0 0 2px gray');
        pdIsVisible = true;
    } else {
        pdContent.setAttribute('style', 'height: 0; padding: 0; box-shadow: 0');
        pdIsVisible = false;
    }
})


//This controls the changing of the default app layout
const layoutIcon = document.querySelector('.setting-option:nth-of-type(2)');
const layoutOptions = document.querySelectorAll('.applayout-menu li');
const mainEle = document.querySelector('main');

layoutIcon.addEventListener('click', e => {
    const arrow = e.target.children[1];
    const menu = e.target.nextElementSibling;
    const options = menu.children;

    menu.setAttribute('style', 'height: 95px; box-shadow: 0 0 0 2px var(--faded-gray)');
    arrow.style.rotate = '180deg';
});


layoutOptions.forEach(option => {
    option.addEventListener('click', e => {
        const arrow = e.target.closest('ul').previousElementSibling.children[1];
        const menu = e.target.closest('ul');

        menu.setAttribute('style', 'height: 0; box-shadow: none');
        arrow.style.rotate = 'initial';
    });
});

layoutOptions[0].addEventListener('click', e => {

    mainEle.style.flexDirection = 'initial';

    sideBarOpen ?
        collapseMenuIcon.setAttribute('style', 'inset: 30px 0 0 8px; translate: -100%; rotate: -180deg') :
        collapseMenuIcon.setAttribute('style', 'inset: 30px 0 0 50%;  translate: -50%; rotate: 360deg');

    if (sideBarOpen) {
        collapseMenuIcon.setAttribute('style', 'inset: 30px 0 0 90%;  translate: -100%; rotate: -180deg');
    } else {
        collapseMenuIcon.setAttribute('style', 'inset: 30px 0 0 50%;  translate: -50%; rotate: initial');
    }
});

layoutOptions[1].addEventListener('click', e => {
    mainEle.style.flexDirection = 'row-reverse';

    sideBarOpen ?
        collapseMenuIcon.setAttribute('style', 'inset: 30px 0 0 8px; translate: 50%; rotate: 360deg') :
        collapseMenuIcon.setAttribute('style', 'inset: 30px 0 0 50%;  translate: -50%; rotate: -180deg');

    collapseMenuIcon.onclick = function (e) {
        if (sideBarOpen) {
            collapseMenuIcon.setAttribute('style', 'inset: 30px 0 0 8px; translate: 50%; rotate: 360deg')
        } else {
            e.target.setAttribute('style', 'inset: 30px 0 0 50%;  translate: -50%; rotate: -180deg');
        }
    }
});



//This code controls the opening and closing of the email filter options
const filterIcon = document.querySelector('#filter-icon');
const filterOptionsWrapper = document.querySelector('#filter-options');

let filterVisible = false
filterIcon.addEventListener('click', e => {
    !filterVisible ?
        (filterOptionsWrapper.setAttribute('style', 'height: 50px;border: 2px solid grey'), filterVisible = true) :
        (filterOptionsWrapper.setAttribute('style', 'height: 0;border: none'), filterVisible = false);
});



//This section hanldes the display and hiding of the UI for different categories of the users email 
const allInbox = document.querySelector('#all-inboxes-UI');
const inbox = document.querySelector('#inbox-UI');
const sent = document.querySelector('#sent-mail-UI');
const drafts = document.querySelector('#drafts-UI');
const spam = document.querySelector('#spam-UI');
const settings = document.querySelector('#settings-UI');
const profileUi = document.querySelector('#account-mgt-UI');
const writeMailUi = document.querySelector('#write-mail-UI');

const composeMailIcon = document.querySelector('#compose-mail');
const mailCategories = document.querySelectorAll('.menu-option');
const settingsIcon = document.querySelector('#settings-icon');
const exitIcon = document.querySelector('#exit-icon');
const acountMGTIcon = document.querySelector('.setting-option:first-of-type');

//This toggles the display of the profile editing UI
acountMGTIcon.addEventListener('click', () => {
    profileUi.style.display = 'block';
});

exitIcon.addEventListener('click', () => profileUi.style.display = 'none');

//Code to display the write new mail UI
composeMailIcon.addEventListener('click', () => {
    inbox.style.display = 'none';
    sent.style.display = 'none';
    drafts.style.display = 'none';
    spam.style.display = 'none';
    settings.style.display = 'none';
    allInbox.style.display = 'none';
    writeMailUi.style.display = 'block';
});

//Code to display the All mail UI
mailCategories[0].addEventListener('click', () => {
    inbox.style.display = 'none';
    sent.style.display = 'none';
    drafts.style.display = 'none';
    spam.style.display = 'none';
    settings.style.display = 'none';
    writeMailUi.style.display = 'none';
    allInbox.style.display = 'initial';
});

//Code to display the inbox UI
mailCategories[1].addEventListener('click', () => {
    allInbox.style.display = 'none';
    inbox.style.display = 'initial';
    sent.style.display = 'none';
    drafts.style.display = 'none';
    spam.style.display = 'none';
    writeMailUi.style.display = 'none';
    settings.style.display = 'none';
});

//Code to display the sent UI
mailCategories[2].addEventListener('click', () => {
    allInbox.style.display = 'none';
    inbox.style.display = 'none';
    sent.style.display = 'initial';
    drafts.style.display = 'none';
    spam.style.display = 'none';
    writeMailUi.style.display = 'none';
    settings.style.display = 'none';
});

//Code to display the drafts UI
mailCategories[3].addEventListener('click', () => {
    allInbox.style.display = 'none';
    inbox.style.display = 'none';
    sent.style.display = 'none';
    drafts.style.display = 'initial';
    spam.style.display = 'none';
    writeMailUi.style.display = 'none';
    settings.style.display = 'none';
});

//Code to display the spam UI
mailCategories[4].addEventListener('click', () => {
    allInbox.style.display = 'none';
    inbox.style.display = 'none';
    sent.style.display = 'none';
    drafts.style.display = 'none';
    spam.style.display = 'initial';
    writeMailUi.style.display = 'none';
    settings.style.display = 'none';
});


//Code to display the settings UI
settingsIcon.addEventListener('click', () => {
    allInbox.style.display = 'none';
    inbox.style.display = 'none';
    sent.style.display = 'none';
    drafts.style.display = 'none';
    spam.style.display = 'none';
    writeMailUi.style.display = 'none';
    settings.style.display = 'initial';
});


//This code handles the user account mangement settings
const editNameInput = document.querySelector('#lb-name + input');
const editRoleInput = document.querySelector('#lb-role + input');
const editDeptInput = document.querySelector('#lb-department + input');
const editEmailStatusInput = document.querySelector('#lb-status + input');

const editRole = document.querySelector('#lb-role');
const editDept = document.querySelector('#lb-department');
const editEmailStatus = document.querySelector('#lb-status');

const userName = document.querySelector('#user-name');
const userRole = document.querySelector('#user-role');
const userDept = document.querySelector('#user-department');
const userEmailStatus = document.querySelector('#user-mail-status');

userName.textContent = editNameInput.value;
userRole.textContent = editRoleInput.value;
userDept.textContent = editDeptInput.value;
userEmailStatus.textContent = editEmailStatusInput.value;

const profileOptions = document.querySelectorAll('.profile-menu li');
const saveBtn = document.querySelector('#save-changes-btn');

const loader = document.querySelector('#settings-loader');
const notification = document.querySelector('#notifications span');


//This function displays the loader animation when the edit profile dropdown menu is requested
function displayLoader(menu, arrow) {
    loader.style.scale = 1;
    setTimeout((menu, arrow) => {
        loader.style.scale = 0;
        arrow.style.rotate = '180deg';
        menu.style.height = 'auto';
        menu.style.boxShadow = '0 0 0 2px gray';

    }, 1500, menu, arrow);
}


//This function displays a message in the notification area when it is called
function displayNotif(msg, delay, UI) {
    notification.textContent = msg;
    notification.closest('section').setAttribute('style', 'background: var(--global-light-purple); color: white; box-shadow: none');
    editNameInput.style.border = '2px solid blue';
    setTimeout(() => {
        notification.textContent = 'New messages available!';
        notification.closest('section').removeAttribute('style');
        UI.style.display = 'none'; //UI to be removed after event is executed successfully
    }, delay);
}


const editArray = [editRole, editDept, editEmailStatus];
editArray.forEach(el => {
    el.addEventListener('click', e => {
        const menu = e.target.closest('fieldset').nextElementSibling;
        const arrow = e.target.children[0];
        displayLoader(menu, arrow); //Calls the loading animation function
    });
});


profileOptions.forEach(option => {
    option.addEventListener('click', e => {
        const menu = e.target.closest('ul');
        const arrow = e.target.closest('ul').previousElementSibling.querySelector('label').children[0];
        const input = e.target.closest('ul').previousElementSibling.children[1];
        menu.style.height = 0;
        menu.style.boxShadow = 'none';
        arrow.style.rotate = 'initial';
        input.value = e.target.textContent;
    });
});


saveBtn.addEventListener('click', e => {

    //Error handling when the save profile changes button is clicked
    if (editNameInput.value === '') {
        e.preventDefault();
        editNameInput.focus();
        editNameInput.style.border = '2px solid red';
        editNameInput.placeholder = 'You cant leave this field empty...';
        return false;
    }
    userName.textContent = editNameInput.value;
    userRole.textContent = editRoleInput.value;
    userDept.textContent = editDeptInput.value;
    userEmailStatus.textContent = editEmailStatusInput.value;
    displayNotif('Changes have been made successfully', 2000, profileUi);
    return true;
});


//This section handles any process related to writng or sending of new email

const emailContent = document.querySelector('#email-content');
const recieversMail = document.querySelector('#recievers-email');
const senMsgIcon = document.querySelector('#send-icon');
const discardMsgIcon = document.querySelector('#discard-icon');
const sendMsgLoader = document.querySelector('#new-mail-loader');
const mailTemplate = document.querySelectorAll('.template-emails');
const dummyMailCont = document.querySelector('.template-mail-content');
const deleteMail = document.querySelectorAll('.delete-mail');
const saveAsDraft = document.querySelector('#save-as-draft');

emailContent.value = dummyTxt;



//This code shuffles the default emails in the inbox UI to add realism to the demo
setInterval(() => {
    const randomNum = Math.floor(Math.random() * 8) + 1;
    inbox.insertAdjacentElement('afterbegin', mailTemplate[randomNum]);
}, 3000);



//The createNewMail function below creates a new email and appends it to any UI you specify 
//It takes four arguments listed below
//1- The main content of the new email
//2- The date the email was sent
//3- The UI that the email should be appended to
//4- The last argument is the profile pic of the sender (default picture is shown if sendersPic returns false);

function createNewMail(eContent, dateSent, appendAt, sendersPic = false) {
    const newMailWrapper = document.createElement('aside');
    const pic = document.createElement('img');
    const sender = document.createElement('span');
    const content = document.createElement('span');
    const deleteMail = document.createElement('img');
    const markSpam = document.createElement('span');
    const date = document.createElement('span');

    newMailWrapper.setAttribute('class', 'template-emails');
    pic.setAttribute('class', 'template-sender-pic');
    sender.setAttribute('class', 'template-sender-email');
    content.setAttribute('class', 'template-mail-content');
    deleteMail.setAttribute('class', 'delete-mail');
    markSpam.setAttribute('class', 'mrk-as-spam');
    date.setAttribute('class', 'date-sent');

    const mailString = `To: ${recieversMail.textContent}`;

    content.textContent = eContent;
    sender.textContent = mailString;
    date.textContent = dateSent;

    sendersPic ? pic.src = sendersPic : pic.src = 'icons/icons8-test-account-96.png';//Default picture is shown if sendersPic returns false
    deleteMail.src = 'icons/icons8-waste-100 (1).png';
    markSpam.textContent = 'Mark as spam';

    newMailWrapper.append(pic, sender, content, deleteMail, markSpam, date);
    appendAt.insertBefore(newMailWrapper, appendAt.children[1]);
}


//This function generates the current date in real time
function getRealDate() {
    const date = new Date();
    const dateFormat = {
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        hour12: true
    }
    const realDate = new Intl.DateTimeFormat('en-US', dateFormat).format(date);
    return realDate;
}


/*--This function displays the loading animation when the send email icon is clicked--*/
function showSendingLoader() {
    sendMsgLoader.style.scale = 1;
    sendMsgLoader.children[1].textContent = 'Sending mail...';
    setTimeout(() => {
        sendMsgLoader.children[1].textContent = 'Sent...redirecting to sent-inbox';
    }, 2000);

    setTimeout(() => {
        sendMsgLoader.style.scale = 0;
        writeMailUi.style.display = 'none';
        sent.style.display = 'block';
    }, 5000);
}


//When the send icon from the write msg UI is clicked it calls the function above to display the loading animation
senMsgIcon.addEventListener('click', e => {
    if (emailContent.value === '') {
        e.preventDefault();
        displayNotif('Proton wont send empty emails', 2000);
    } else {
        createNewMail(emailContent.value, getRealDate(), sent);
        showSendingLoader();
        displayNotif('Sending mail', 5000);
    }
});


//This code discards a new email and resets the email text area 
discardMsgIcon.addEventListener('click', () => {
    writeMailUi.style.display = 'none';
    inbox.style.display = 'block';
    emailContent.value = '';
    displayNotif('Mail Discarded', 2000, writeMailUi);
});


//This code discards a new email and resets the text area before it gets sent
saveAsDraft.addEventListener('click', () => {
    writeMailUi.style.display = 'none';
    drafts.style.display = 'block';
    createNewMail(emailContent.value, getRealDate(), drafts);
    displayNotif('Mail saved as draft', 3000, writeMailUi);
});



